declare module "@vertix.gg/embed/src/discord-embed" {
    const Component: any;
    export = Component;
    export default Component;
}

declare module "@vertix.gg/embed/src/discord-button" {
    const Component: any;
    export = Component;
    export default Component;
}
