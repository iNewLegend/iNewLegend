export default function Credits() {
    return (
        <div className="container box-1">
            <h1 className="text-center mt-3">We want say thanks to</h1>
            <ul className="mt-4">
                <li>
                    <h5><b>Komendant Chris</b> <code>@christos56</code> for adding <strong>Greek</strong> <span className="fs-3">🇬🇷</span>&nbsp;&nbsp;language translation.</h5>
                </li>
            </ul>
        </div>
    );
}
