export const VAR_DYNAMIC_CHANNEL_USER = "{user}" as const,
    VAR_DYNAMIC_CHANNEL_STATE = "{state}" as const,
    VAR_DYNAMIC_CHANNEL_GAME = "{game}" as const;
