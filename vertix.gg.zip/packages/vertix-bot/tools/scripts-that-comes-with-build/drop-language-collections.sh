mongosh discord --eval "db.ElementButtonLanguage.drop()
                        db.ElementButtonLanguageModal.drop()
                        db.ElementSelectMenuLanguage.drop()
                        db.ElementTextInputLanguage.drop()
                        db.EmbedLanguage.drop()
                        db.MarkdownLanguage.drop()
                        db.ModalLanguage.drop()";
