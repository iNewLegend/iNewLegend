import { entryPoint } from "@vertix.gg/bot/src/entrypoint";

Error.stackTraceLimit = Infinity;

await entryPoint( {} );
