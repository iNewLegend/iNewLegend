![]({userWonDisplayAvatarURL})

## {userWonDisplayName} has claimed the channel and is now the new owner!

Previous owner: ~~{previousOwnerDisplayName}~~

It took {elapsedTimeSeconds} seconds and {resultsLength} candidates to complete the vote.

## Candidates
\# | User | Votes
:----: | :----: | :----:
{displayNameAndResults}

## Votes
Who | For
:----: | :----:
{votesForMembersResults}
