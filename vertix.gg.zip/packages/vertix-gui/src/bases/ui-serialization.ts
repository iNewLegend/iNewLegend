export type {
    UISerializationComponent as ComponentSerializer,
    UISerializationContext as SerializationContext,
    UISerializationComponentSchemaResult as ComponentSchemaResult
} from "@vertix.gg/definitions/src/ui-serialization-definitions";
