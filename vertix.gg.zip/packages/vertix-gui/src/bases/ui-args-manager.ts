import { GuildChannel, Message } from "discord.js";

import { InitializeBase } from "@vertix.gg/base/src/bases/index";

import { createDebugger } from "@vertix.gg/base/src/modules/debugger";

import { ArgsNotFoundError } from "@vertix.gg/gui/src/bases/errors/args-not-found-error";

import type { Debugger } from "@vertix.gg/base/src/modules/debugger";

import type { UIBase } from "@vertix.gg/gui/src/bases/ui-base";

import type { UIArgs } from "@vertix.gg/gui/src/bases/ui-definitions";
import type { UIAdapterReplyContext, UIAdapterStartContext } from "@vertix.gg/gui/src/bases/ui-interaction-interfaces";

export class UIArgsManager extends InitializeBase {
    private debugger: Debugger;

    private data: {
        [ownerName: string]: {
            [argsId: string]: {
                args: UIArgs;
                createdAt: Date;
                updatedAt: Date;
                accessedAt: Date;
            };
        };
    } = {};

    public static getName() {
        return "VertixGUI/UIArgsManager";
    }

    public constructor( private readonly prefixName: string ) {
        super();

        this.debugger = createDebugger( this, "UI", prefixName );
    }

    // TODO: Remove this method, it should be handled by initiator
    public getArgsId( context: UIAdapterStartContext | UIAdapterReplyContext | Message<true> ): string {
        let id;

        if ( context instanceof GuildChannel ) {
            id = context.id;
        } else if ( context instanceof Message ) {
            id = context.id;
        } else if ( context.isCommand() ) {
            id = context.id;
        } else if ( context.isMessageComponent?.() ) {
            id = context.message.id;
        } else if ( context.isModalSubmit?.() ) {
            id = context.message?.id ?? context.id;
        } else {
            id = context.message?.id;
        }

        this.logger.debug( this.getArgsId, `Resolved ID: '${ id }' for context type: ${ context.constructor.name }` );
        this.debugger.log( this.getArgsId, "", id );

        if ( !id ) {
            throw new Error( "Invalid interaction id" );
        }

        return id;
    }

    public getArgsById( self: UIBase, id: string ): UIArgs {
        return this.data[ self.getName() ]?.[ id ]?.args;
    }

    public getArgs( self: UIBase, context: UIAdapterStartContext | UIAdapterReplyContext | Message<true> ): UIArgs {
        const argsId = this.getArgsId( context ),
            args = this.getArgsById( self, argsId );

        // Update accessedAt.
        if ( args ) {
            this.data[ self.getName() ][ argsId ].accessedAt = new Date( Date.now() );

            // Create proxy to update accessedAt.
            return new Proxy( Object.assign( {}, args ), {
                get: ( target, property: string ) => {
                    // If not exist return undefined
                    if (
                        "undefined" === typeof this.data[ self.getName() ] ||
                        "undefined" === typeof this.data[ self.getName() ][ argsId ]
                    ) {
                        return undefined;
                    }

                    this.data[ self.getName() ][ argsId ].accessedAt = new Date( Date.now() );

                    return target[ property ];
                }
            } );
        }

        return args;
    }

    public setInitialArgs(
        self: UIBase,
        id: string,
        args: UIArgs,
        internalArgs: {
            silent?: boolean;
            overwrite?: boolean;
        } = {}
    ) {
        this.logger.debug( this.setInitialArgs, `Setting initial args for: '${ self.getName() }' id: '${ id }'` );
        this.debugger.log( this.setInitialArgs, self.getName() + "~" + id, args );

        if ( typeof this.data[ self.getName() ] !== "object" ) {
            this.data[ self.getName() ] = {};
        }

        if ( !internalArgs.overwrite && typeof this.data[ self.getName() ][ id ] === "object" ) {
            this.logger.debug( this.setInitialArgs, `Args already exist for: '${ self.getName() }' id: '${ id }', skipping initialization because overwrite is false.` );
            this.debugger.dumpDown( this.setInitialArgs, this.data[ self.getName() ][ id ] );

            if ( !internalArgs.silent ) {
                this.logger.error( this.setInitialArgs, `${ this.prefixName }: Args with name: '${ self.getName() }' id: '${ id }' already exists` );
                return;
            }

            this.logger.error( this.setInitialArgs, `${ this.prefixName }: Args with id: '${ id }' already exists` );
            this.deleteArgs( self, id );
            return;
        }

        this.data[ self.getName() ][ id ] = {
            args: args || {},
            createdAt: new Date( Date.now() ),
            updatedAt: new Date( Date.now() ),
            accessedAt: new Date( Date.now() )
        };
    }

    public setArgs(
        self: UIBase,
        interaction: Message<true> | UIAdapterReplyContext | UIAdapterStartContext,
        args: UIArgs
    ) {
        const argsId = this.getArgsId( interaction ),
            appliedArgs = this.getArgsById( self, argsId );

        if ( !appliedArgs ) {
            // TODO: Good error example.
            const error = new ArgsNotFoundError( argsId );

            this.logger.error( this.setArgs, `ArgsNotFound for: '${ self.getName() }' id: '${ argsId }'. Available keys for this owner: ${ Object.keys( this.data[ self.getName() ] || {} ).join( ", " ) }`, error );

            return;
        }

        const newArgs: any = {};

        Object.entries( args ).forEach( ( [ key, value ] ) => {
            newArgs[ key ] = value;

            appliedArgs[ key ] = value;
        } );

        this.data[ self.getName() ][ argsId ].updatedAt = new Date( Date.now() );
        this.data[ self.getName() ][ argsId ].accessedAt = new Date( Date.now() );

        this.debugger.log( this.setArgs, "", newArgs );
    }

    public deleteArgs( self: UIBase | string, id: string ) {
        if ( typeof self !== "string" ) {
            self = self.getName();
        }

        this.debugger.log( this.deleteArgs, `Try delete args with id: '${ self + "~" + id }'` );

        const object = this.data[ self ];

        if ( typeof object === "object" ) {
            this.debugger.dumpDown( this.deleteArgs, object[ id ], `Deleted args with id: '${ self + "~" + id }'` );

            delete object[ id ];

            if ( Object.keys( object ).length === 0 ) {
                delete this.data[ self ];
            }
        } else {
            this.logger.warn( this.deleteArgs, `Args with id: '${ self + "~" + id }' not found` );
        }
    }

    public getData() {
        return this.data;
    }
}
