export const UI_MAX_CUSTOM_ID_LENGTH = 100;
