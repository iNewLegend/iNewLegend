import { entryPoint } from "@vertix.gg/api/src/entrypoint";

entryPoint();
