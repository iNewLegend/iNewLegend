declare module "@xyflow/react/dist/style.css";

